% Constants file.
% All constants should go in one m file. 

m = 1.5; % kg, mass.
k1 = 5; % N/m, spring constant.
k2 = 0.5; % N/m, second spring constant.
d = 0.35; % N/(m/2), damping constant.
gamma1 = 0.1*0; % N, amplitute of forcing function; note ``gamma'' is a function, which is why I use ``gamma1'' as the variable. Try ``help gamma'' in the command window.
omega = 10;; % rad/s, frequency of forcing function.

dummy_matix = blkdiag([1 2; 3 4], 1);