function  [x_dot] = ODEs(t,x,output_flag,dummy_matix,t_span,waitbar_handle);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Call constants
constants

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Dynamics

% First, extract states in a convenient form. 
x1 = x(1);
x2 = x(2);

% Form dot_x = f(x,u) system.
dot_x1 = x2;
dot_x2 = 1/m*( - k1*x1 - k2*x1^3 - d*x2 + gamma1*cos(omega*t) );

dot_x = [dot_x1; dot_x2];

% Could also use this code
% dot_x = [x2; 1/m*( - k1*x1 - k2*x1^3 - d*x2 + gamma1*cos(omega*t) )];


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output.
if (output_flag == 0)
    % Output the rate of change of x.
    x_dot = dot_x;
    waitbar(t/t_span(length(t_span)),waitbar_handle);
    
elseif (output_flag == 1)   
    % This is for other kinds of post processing; not needed right now.
    x_dot = x;
    
end


