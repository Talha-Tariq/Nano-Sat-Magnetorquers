% Plotting script.
% James Richard Forbes

% close all

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Font size, line size, and line width. 
font_size = 15;
line_size = 15;
line_width = 2;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plots.
% I like to create .eps files. (If you don't know what an .eps file is,
% goodle it.) You can create other kinds of files, such as .png. For more
% information, type ``help print'' in the command window.

% System response
figure
subplot(2,1,1)
plot(t,x_out(:,1),'Linewidth',line_width);
hold on
xlabel('Time (s)','fontsize',font_size,'Interpreter','latex');
ylabel('$x_1$ (m)','fontsize',font_size,'Interpreter','latex');
set(gca,'XMinorGrid','off','GridLineStyle','-','FontSize',line_size)
grid on
subplot(2,1,2)
plot(t,x_out(:,2),'Linewidth',line_width);
hold on
xlabel('Time (s)','fontsize',font_size,'Interpreter','latex');
ylabel('$x_2$ (m/s)','fontsize',font_size,'Interpreter','latex');
set(gca,'XMinorGrid','off','GridLineStyle','-','FontSize',line_size)
grid on

% print -depsc -r720 plots/duffing_sys_resp
exportfig(gcf,'plots/duffing_sys_resp.eps','width',11,'Height',8.5,'fontmode','fixed','fontsize',20,'Color','cmyk','LineWidth',line_width);

% Phase-space plot
figure
plot(x_out(:,1),x_out(:,2),'Linewidth',line_width);
hold on
xlabel('$x_2$ (m)','fontsize',font_size,'Interpreter','latex');
ylabel('$x_2$ (m/s)','fontsize',font_size,'Interpreter','latex');
set(gca,'XMinorGrid','off','GridLineStyle','-','FontSize',line_size)
grid on

% print -depsc -r720 plots/duffing_energy
exportfig(gcf,'plots/duffing_energy.eps','width',11,'Height',8.5,'fontmode','fixed','fontsize',20,'Color','cmyk','LineWidth',line_width);

% Energy, which should be constant when damping is zero and the forcing function is zero. 
figure
plot(t,E,'Linewidth',line_width);
hold on
xlabel('Time (s)','fontsize',font_size,'Interpreter','latex');
ylabel('$E$ (J)','fontsize',font_size,'Interpreter','latex');
set(gca,'XMinorGrid','off','GridLineStyle','-','FontSize',line_size)
grid on

% print -depsc -r720 plots/duffing_energy
exportfig(gcf,'plots/duffing_energy.eps','width',11,'Height',8.5,'fontmode','fixed','fontsize',20,'Color','cmyk','LineWidth',line_width);