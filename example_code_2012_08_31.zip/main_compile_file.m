% James Richard Forbes
% 2012/08/31

% This is a piece of sample code written by me, Prof. Forbes, for MECH 513. 
% It's purpose is to show students how to neatly, clearly, and properly
% use matlab.
%
% We will simulate a mass-spring-damper system where the spring is 
% nonlinear; this is a Duffing Oscillator (google it if you have too).
% To start, we will have the forcing function off (i.e., gamm1 = 0.1*0). 
% You should play with the damping parameter (i.e., set d = 0, then 
% d = 0.1) to see how the system response changes. Then, after you've had 
% enough of tweaking parameters, turn the forcing function on. The purpose 
% of this code is to show students how to use matlab to numerically
% integrate DEs, and how to write clean code. This code is not
% ``perfect'' in that I have my own personal style, but it is clean,
% reasonably commented, and overall neat and tidy. 

clear all
clc
close all
format long

% profile on; % Try uncommenting this ``profile off;'' code at the bottom.

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Constants 
constants % All constants in one file. 

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial conditions.
IC = [.1 0].';

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation time.
t0 = 0; % s
t_max = 20; % s
t_div = 101;
t_span = linspace(t0,t_max,t_div); % Total simulatoin time.
% t_span = [0 t_max];

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation options.
% options = odeset('AbsTol',1e-10,'RelTol',1e-10); % This changes the integration tolerence.
options = [];

tic
waitbar_handle = waitbar(0,'Numerical Integration Progress');
output_flag = 0;

% Use any solver; I use these three the most. 
% [t,x_out] = ode45(@ODEs,t_span,IC,options,output_flag,dummy_matix,t_span,waitbar_handle);
% [t,x_out] = ode15s(@ODEs,t_span,IC,options,output_flag,dummy_matix,t_span,waitbar_handle);
[t,x_out] = ode113(@ODEs,t_span,IC,options,output_flag,dummy_matix,t_span,waitbar_handle);

close(waitbar_handle);
time_stamp = toc

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Post Processing
post_processing

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot data
plot_script_v1

% profile off;
% profview;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Save all the data. (You never know when you'll need it again.)
save sim_data_v1